//
//  BearerToken.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 02/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

struct BearerToken: Decodable {
    var access_token: String
}
