//
//  TweetObject.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 04/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation
import CoreData

public class TweetObject: NSManagedObject {}


