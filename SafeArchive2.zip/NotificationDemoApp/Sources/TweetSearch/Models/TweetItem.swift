//
//  Tweet.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 30/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

struct TweetItem {
    let message: String
    let id: String
    let date: String
    let liked: String
    let retweet: String
    let userName: String
    let userID: String
    let profilePicture: String
}
