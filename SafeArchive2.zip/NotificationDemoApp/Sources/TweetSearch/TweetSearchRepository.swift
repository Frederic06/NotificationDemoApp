//
//  TwiiterSearchRepository.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 29/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation
import CoreData

final class TweetSearchRepository {
    
    private let network = Network()
    
    private let route = Route()

    func checkIfFavorite(hashtag: String, completion: ((Bool) -> Void)){
    }

        func getTweets(hashTag: String, success: @escaping (Result<[TweetItem]>) -> Void, onError: @escaping (String) -> Void) {

            guard let url = route.getUrl(hashtag: hashTag) else {return}
            network.requestTwitter(type: Tweet.self, url: url) { (result) in
                switch result {
                case .success(value: let foundTweets):
                    let tweets: [TweetItem] = foundTweets.statuses.map{ return
                        TweetItem(message: $0.text, id: String($0.id), date: $0.created_at, liked: String($0.favorite_count), retweet: String($0.retweet_count), userName: $0.user.screen_name, userID: String($0.user.id), profilePicture: $0.user.profile_image_url_https )}
                    success(.success(value: tweets))

                case .error(let error):
                    print(error)
                }
            }
        }
    
    func getTweets(hashTag: String, latitude: String, longitude: String, success: @escaping (Result<[TweetItem]>) -> Void, onError: @escaping (String) -> Void) {

        guard let url = route.getUrl(hashtag: hashTag, latitude: latitude, longitude: longitude) else {return}
            network.requestTwitter(type: Tweet.self, url: url) { (result) in
                switch result {
                case .success(value: let foundTweets):
                    let tweets: [TweetItem] = foundTweets.statuses.map{ return
                        TweetItem(message: $0.text, id: String($0.id), date: $0.created_at, liked: String($0.favorite_count), retweet: String($0.retweet_count), userName: $0.user.screen_name, userID: String($0.user.id), profilePicture: $0.user.profile_image_url_https)}
                    success(.success(value: tweets))

                case .error(let error):
                    print(error)
                }
            }
        }
    
    func getSavedTweet(completion: @escaping (Result<[TweetItem]>) -> Void) {
            let request: NSFetchRequest<TweetObject> = TweetObject.fetchRequest()
            
            guard let tweets = try? AppDelegate.viewContext.fetch(request) else { return}
        let tweetObject : [TweetItem] = tweets.map  { return TweetItem(message: $0.message ?? "", id: $0.id ?? "", date: $0.date ?? "", liked: $0.liked ?? "", retweet: $0.retweet ?? "", userName: $0.userName ?? "", userID: $0.id ?? "", profilePicture: $0.profilePicture ?? "")
            }
        completion(.success(value: tweetObject))
        }

   }
