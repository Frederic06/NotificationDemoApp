//
//  TweetDetailRepository.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 03/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation
import CoreData

final class TweetDetailRepository {
    
    func saveTweet(tweet: TweetItem) {
        print(tweet)
        let tweetObject = TweetObject(context: AppDelegate.viewContext)
        tweetObject.date = tweet.date
        tweetObject.id = tweet.id
        tweetObject.liked = tweet.liked
        tweetObject.message = tweet.message
        tweetObject.profilePicture = tweet.profilePicture
        tweetObject.retweet = tweet.profilePicture
        tweetObject.userID = tweet.userID
        tweetObject.userName = tweet.userName
        print(tweetObject.userID)
        try? AppDelegate.viewContext.save()
    }
    
    func removeFavorite(tweetID: String) {
        
            let request: NSFetchRequest<TweetObject> = TweetObject.fetchRequest()
            request.predicate = NSPredicate(format: "id == %@", tweetID)
            
        do {
            let object = try AppDelegate.viewContext.fetch(request)
            if !object.isEmpty {
                AppDelegate.viewContext.delete(object[0])
                try? AppDelegate.viewContext.save()
            }
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func checkIfFavorite(tweetID: String, completion: (Bool) -> Void) {
        let request: NSFetchRequest<TweetObject> = TweetObject.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", tweetID)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \TweetObject.id, ascending: true)]
        
        guard let tweet = try? AppDelegate.viewContext.fetch(request) else { print("error") ; return }
        
        if tweet == [] {completion(false); return }
        
        completion(true)
    }
}
