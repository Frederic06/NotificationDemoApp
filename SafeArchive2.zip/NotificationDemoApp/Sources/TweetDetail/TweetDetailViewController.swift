//
//  DetailViewController.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 29/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

class TweetDetailViewController: UIViewController {
    
    var viewModel: TweetDetailViewModel!

    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var profileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bind(to: viewModel)
        viewModel.viewDidLoad()
        configureUI()
    }
    
    func bind(to viewModel: TweetDetailViewModel) {
        viewModel.profilePictureString = { [weak self] image in
            guard let image = image.loadImage() else {print("ALERT"); return}
            self?.profileImage.image = image
        }
    }
    
    private func configureUI() {
        navigationItem.title = "👉Tweet Detail"
    }
    
    @IBAction func saveButton(_ sender: UIButton) {
        viewModel.didPressSave()
    }
}
