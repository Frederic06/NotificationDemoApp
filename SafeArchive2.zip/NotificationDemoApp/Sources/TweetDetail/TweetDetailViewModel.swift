//
//  TweetDetailViewModel.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 03/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

protocol TweetDetailViewModelDelegate: class {
    func didPressFavorite(tweet: TweetItem)
    func displayAlarm(type: AlertType)
}

final class TweetDetailViewModel {
    
    // MARK: - Properties
    
    private weak var delegate: TweetDetailViewModelDelegate?
    
    private var repository: TweetDetailRepository
    
    private var tweet: TweetItem
    
    // MARK: - Init
    
    init(delegate: TweetDetailViewModelDelegate?, repository: TweetDetailRepository, tweet: TweetItem) {
        
        self.delegate = delegate
        self.repository = repository
        self.tweet = tweet
    }
    
    // MARK: - Output
    
    var profilePictureString: ((String) -> Void)?
    
    // MARK: - Methods
    
    func viewDidLoad() {
        profilePictureString?(tweet.profilePicture)
        print(tweet.profilePicture)
    }
    
    func didPressSave(){
        repository.saveTweet(tweet: tweet)
    }
}
