//
//  Route.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 01/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

enum Parameters {
    case hashtagOnly, userLocation
}

class Route {
    
    private let baseUrl = "https://api.twitter.com/1.1/search/tweets.json?q="
    
    func getUrl(requestParameters: Parameters, hashtag: String, location: String) -> URL? {
        
        switch requestParameters {
        case .hashtagOnly:
            
            let urlString = "\(baseUrl)\(hashtag)"
            guard let url = URL(string: urlString) else {return nil}
            return url
            
        case .userLocation:
            let urlString = "\(baseUrl)\(location)"
            guard let url = URL(string: urlString) else {return nil}
            return url
        }
    }
}
