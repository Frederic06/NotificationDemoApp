//
//  Screens.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 28/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

final class Screens {
    
    let storyboard = UIStoryboard(name: "Main", bundle: Bundle(for: Screens.self))
}

// MARK: - Search

extension Screens {
    func createTwitterSearchViewController(persistence: Bool, delegate: TwitterSearchViewModelDelegate?) -> UIViewController {
        let viewController = storyboard.instantiateViewController(withIdentifier: "TwitterSearchViewController") as! TwitterSearchViewController
        let repository = TwiterSearchRepository()
        let viewModel = TwitterSearchViewModel(persistence: persistence, delegate: delegate, repository: repository)
        viewController.viewModel = viewModel
        return viewController
    }
}

extension Screens {
    func createTweetDetailViewController() -> UIViewController {
        let viewController = storyboard.instantiateViewController(withIdentifier: "TweetDetailViewController") as! TweetDetailViewController
        print("CREATION ok screens")
        return viewController
    }
}
