//
//  ExtensionsProtocols.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 30/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

extension String {
           func toBase64() -> String {
            return Data(self.utf8).base64EncodedString()
    }
}




