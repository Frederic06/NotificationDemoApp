//
//  SearchCoordinator.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 03/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

final class SearchCoordinator {

// MARK: - Properties

private let presenter: UINavigationController
private let screens: Screens

// MARK: - Initializer

init(presenter: UINavigationController, screens: Screens) {
    self.presenter = presenter
    self.screens = screens
}

// MARK: - Coordinator

func start() {
    showSearch()
}
    private func showSearch() {
        let viewController = screens.createTwitterSearchViewController(persistence: false, delegate: self as? TwitterSearchViewModelDelegate)
        presenter.viewControllers = [viewController]
    }
    
    private func showHashtags() {
               print("showHashtags APPCOORDINATOR")
        let viewController = screens.createTweetDetailViewController()
        presenter.pushViewController(viewController, animated: true)
    }
}

//extension AppCoordinator: TwitterSearchViewModelDelegate {
//    func didPressHashTagList() {
//        showHashtags()
//    }
//
//    func displayAlert(type: AlertType) {
//    }
//
//    func didPressButton() {
//        showHashtags()
//    }
//}
