//
//  AppCoordinator.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 28/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

final class AppCoordinator {

    // MARK: - Properties
    
    private let presenter: UIWindow
    
    private let navController: UINavigationController
    
    private let screens = Screens()

    // MARK: - Init
    
    init(presenter: UIWindow) {
        
        self.presenter = presenter
        navController = UINavigationController(rootViewController: UIViewController())
    }

    // MARK: - Coordinator

    func start() {
        
        presenter.rootViewController = navController
        
        presenter.makeKeyAndVisible()
        
        showSearch()
    }
    
    private func showSearch() {
        let viewController = screens.createTwitterSearchViewController(persistence: false, delegate: self)
        navController.viewControllers = [viewController]
    }
    
    private func showHashtags() {
        let viewController = screens.createTweetDetailViewController()

        navController.pushViewController(viewController, animated: true)
    }
}

extension AppCoordinator: TwitterSearchViewModelDelegate {
    func didPressHashTagList() {
        showHashtags()
    }
    
    func displayAlert(type: AlertType) {
    }
    
    func didPressButton() {
        showHashtags()
    }
}


