//
//  FavoriteCoordinator.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 03/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//
import UIKit

final class FavoriteCoordinator{

// MARK: - Properties

private let presenter: UINavigationController
private let screens: Screens

// MARK: - Initializer

init(presenter: UINavigationController, screens: Screens) {
    self.presenter = presenter
    self.screens = screens
}
    
    func start() {
        showSearchListViewController()
    }
    
    func createTweetDetail() {
        screens.createTwitterSearchViewController(persistence: true, delegate: self as? TwitterSearchViewModelDelegate)
    }
    
    func showSearchListViewController() {
        screens.createTweetDetailViewController()
    }

}
