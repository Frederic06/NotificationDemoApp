//
//  Tweet.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 30/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

struct TweetItem {
    let name: String
    let message: String
    let id: Int
    let date: String
    
    struct User {
        let username: String
        let id: Int
        let profilePicture: String
    }
}



