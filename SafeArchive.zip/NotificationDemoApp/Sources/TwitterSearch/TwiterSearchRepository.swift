//
//  TwiiterSearchRepository.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 29/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

final class TwiterSearchRepository {
    
    private let network = Network()
    
    private let route = Route()

    func checkIfFavorite(hashtag: String, completion: ((Bool) -> Void)){
    }

    func getTweets(hashTag: String, success: @escaping (Result<[TweetItem]>) -> Void, onError: @escaping (String) -> Void) {


        guard let url = route.getUrl(requestParameters: .hashtagOnly, hashtag: hashTag, location: "") else {return}

        network.requestTwitter(type: Tweet.self, url: url) { (result) in
            switch result {
            case .success(value: let foundTweets):
                let tweets: [TweetItem] = foundTweets.statuses.map{ return
                    TweetItem(name: "", message: $0.text, id: $0.id, date: "")}
                success(.success(value: tweets))

            case .error(let error):
                print(error)
            }
        }
    }
   }
  
        
//        network.getTweets(type: Tweet.self, url: url) { (result) in
//            switch result {
//            case .success(value: let foundTweets):
//                let tweets: [TweetItem] = foundTweets.statuses.map{ return
//                    TweetItem(name: $0.user.screen_name, message: $0.text, id: $0.id, date: $0.created_at)}
//                    success(.success(value: tweets))
//
//            case .error(let error):
//                print(error)
//            }
//        }
//    }

