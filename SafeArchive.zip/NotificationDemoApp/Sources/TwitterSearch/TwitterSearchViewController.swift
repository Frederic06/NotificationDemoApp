//
//  SearchViewController.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 28/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

class TwitterSearchViewController: UIViewController {
    

    @IBOutlet weak var twitterTableView: UITableView!
    
    var viewModel: TwitterSearchViewModel!
    
    private lazy var twitterSearchDataSource = TwitterSearchDataSource()
    
    private lazy var searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        bind(to: viewModel)
        viewModel.viewDidLoad()
        
        bind(to: twitterSearchDataSource)
        
        configureUI()

        view.backgroundColor = .blue
        
        twitterTableView.dataSource = twitterSearchDataSource
        twitterTableView.delegate = twitterSearchDataSource
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationItem.largeTitleDisplayMode = .automatic
        navigationController?.navigationBar.prefersLargeTitles = true
        
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.searchController = searchController
        
        searchController.searchBar.delegate = self
        
        definesPresentationContext = true

    }
    

    private func bind(to viewModel: TwitterSearchViewModel) {
        
        viewModel.searchPlaceHolder = { [weak self] text in
            self?.searchController.searchBar.placeholder = text
        }
        
        viewModel.hashtagLabel = { [weak self] hashtag in
            self?.twitterSearchDataSource.udpate(hashtag: hashtag)
            self?.twitterTableView.reloadData()
        }
        
        viewModel.tweets = { [weak self] tweets in
            self?.twitterSearchDataSource.update(tweets: tweets)
            self?.twitterTableView.reloadData()
            
        }
        
    }
    
    private func bind(to source: TwitterSearchDataSource) {
        source.didPressHashtagList = viewModel.didPressButtonHashtagList
        }
    
    
    @objc private func didPressFavorite() {
        viewModel.clickedOnFavorite()
    }
    

    func configureUI() {
        navigationController?.navigationBar.backgroundColor = #colorLiteral(red: 0.1076729968, green: 0.6331808567, blue: 0.9505664706, alpha: 1)
        navigationItem.title = "Recent tweets"
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // MARK: - IBACTIONS
    
}

extension TwitterSearchViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        guard let text = searchController.searchBar.text else { return }
        viewModel.didWriteHashtag(text: text)
        DispatchQueue.main.async {
            self.searchController.isActive = false
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
//        viewModel.didWriteHashtag(text: searchText)

    }
}
