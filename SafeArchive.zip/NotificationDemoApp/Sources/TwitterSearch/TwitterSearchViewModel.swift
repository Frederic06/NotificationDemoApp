//
//  SearchViewModel.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 29/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

protocol TwitterSearchViewModelDelegate: class {
    func didPressButton()
    func displayAlert(type: AlertType)
    func didPressHashTagList()
}

final class TwitterSearchViewModel {
    
    // MARK: - Properties
    
    private weak var delegate: TwitterSearchViewModelDelegate?
    
    private weak var repository: TwiterSearchRepository?
    
    private var persistence: Bool?
    
    let jopa = TwiterSearchRepository()
    
    
    // MARK: - Init
    
    init(persistence: Bool, delegate: TwitterSearchViewModelDelegate?, repository: TwiterSearchRepository?) {
        self.persistence = persistence
        self.delegate = delegate
        self.repository = repository
    }
    
    // MARK: - Output
    
    var searchPlaceHolder: ((String) -> Void)?
    
    var favoriteStatus: ((Bool) -> Void)?
    
    var tweets: (([TweetItem]) -> Void)?
    
    var hashtagLabel: ((String) -> Void)?
    
    func viewDidLoad() {
        searchPlaceHolder?("Type a hashtag here 👊")
    }
    
    func didPressButtonHashtagList() {
        print("didPressButtonHashtagList VIEWMODEL")
        delegate?.didPressHashTagList()
    }
    
    func didWriteHashtag(text: String) {
        switch persistence {
        case true:
            print("Implemant persistence")
        case false:
            hashtagLabel?("#\(text)")
            repository?.checkIfFavorite(hashtag: text, completion: { (state) in
                favoriteStatus?(state)
            })
            jopa.getTweets(hashTag: text, success: { (response) in
                switch response {
                case .success(value: let tweetArray):
                    self.tweets?(tweetArray)
                case .error(let error):
                    print(error)
                    self.delegate?.displayAlert(type: .networkError)
                }
            }) { (error) in
                print(error)
            }
        default: break
        }
    }
    
    func clickedOnFavorite() {
        print(clickedOnFavorite)
    }
    
}
