//
//  TwitterSearchDataSource.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 29/09/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import UIKit

final class TwitterSearchDataSource: NSObject, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: - Private properties
    
    private var hashtag: String? = nil
    private var tweetArray: [TweetItem]? = nil
    private var buttonFavoriteListText: String? = nil
    
    // MARK: - Public properties
    
    var didPressSaveHashtag: ((String) -> Void)?
    
    var didPressHashtagList: (() -> Void)?
    
    func udpate(hashtag: String) {
        self.hashtag = hashtag
    }
    
    func update(text: String) {
        self.buttonFavoriteListText = text
    }
    
    func update(tweets: [TweetItem]) {
        self.tweetArray = tweets
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          switch section {
              case 0:
                  return 1
              case 1:
                guard let tweets = tweetArray else { return 0}
                return tweets.count
              default:
                  return 0
              }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        switch indexPath.section {
        case 0:
            guard let hashtagText = hashtag else {return cell}

            let cell = tableView.dequeueReusableCell(withIdentifier: "TitleCell", for: indexPath)as! TitleCell
            tableView.rowHeight = 100
            let viewModel = TitleCellViewModel(at: indexPath.item, delegate: self, hashTag: hashtagText)
            cell.configure(with: viewModel)
            
            return cell
            
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TweetCell", for: indexPath)as! TweetCell
            tableView.rowHeight = 200
            guard let tweets = tweetArray else { return cell}
            cell.updateCell(tweet: tweets[indexPath.row])
            return cell

        default:
            print("Default Selected")
            
        }
        return cell

    }
    
}

extension TwitterSearchDataSource: TitleCellDelegate {
    func didPressHashTagList() {
        print("TwitterSearchDataSource")
        self.didPressHashtagList?()
    }
    
    func didPressFavorite(hashtag: String) {
        self.didPressSaveHashtag?(hashtag)
    }
}


 

