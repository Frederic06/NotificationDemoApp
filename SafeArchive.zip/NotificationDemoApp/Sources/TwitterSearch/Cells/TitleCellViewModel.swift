//
//  TitleCellViewModel.swift
//  NotificationDemoApp
//
//  Created by Margarita Blanc on 02/10/2019.
//  Copyright © 2019 Frederic Blanc. All rights reserved.
//

import Foundation

final class TitleCellViewModel {

//     MARK: - Properties

    private let index: Int

    private weak var delegate: TitleCellDelegate?
    
    private var hashTag: String? = nil

    // MARK: - Initializer

    init(at index: Int, delegate: TitleCellDelegate?, hashTag: String) {
        self.index = index
        self.delegate = delegate
        self.hashTag = hashTag
    }

    // MARK: - Outputs

var hashtagLabel: ((String) -> Void)?

var hashtagListeButtonText: ((String) -> Void)?

var favoriteStatus: ((Bool) -> Void)?

    // MARK: - Inputs
    func configure() {
        guard let hashTag = hashTag else {return}
        hashtagLabel?(hashTag)
        hashtagListeButtonText?("Press to manage Hashtags")
        favoriteStatus?(true)
    }
    
    func clickedOnFavorite() {
        print("clickedOnFavorite")
        guard let hashtag = hashTag else {return}
        delegate?.didPressFavorite(hashtag: hashtag)
    }
    
    func clickedOnFavoriteList() {
        print("clickedOnFavorite LIST")
        delegate?.didPressHashTagList()
    }
    
    
}

